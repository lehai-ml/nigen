# NIMAGEN: Statistical and Visualisation tool for NeuroIMAging GENetics studies

See the online documentation

## Quick install

1. `pip install lehai-ml/nimagen`
2. `conda install -c lehai-ml nimagen`
